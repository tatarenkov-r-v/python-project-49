# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '1.0.1',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/tatarenkov-r-v/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/tatarenkov-r-v/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/tatarenkov-r-v/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/6dc7d84679b910c8758b/maintainability" /></a>\n\n\n\nИгры разума - учебный проект, выполненный в рамках обчения языку Python на образовательной платформе Хекслет.\nВключает в себя мини игры на выбор:\n\nBrain-even - "Проверка на чётность".\nПользователю показывается случайное число. И ему нужно ответить yes, если число чётное, или no — если нечётное.\n\nBrain-calc - "Калькулятор".\nПользователю показывается случайное математическое выражение, например 35 + 16, которое нужно вычислить и записать правильный ответ.\n\nBrain-gcd - "Наибольший общий делитель" (НОД).\nПользователю показывается два случайных числа, например, 25 50. Пользователь должен вычислить и ввести наибольший общий делитель этих чисел.\n\nBrain-progression - "Арифметическая прогрессия".\nПользователю показывается ряд чисел, образующий арифметическую прогрессию, заменив любое из чисел двумя точками. Пользователь должен определить это число.\n\n\nBrain-even demonstration:\nhttps://asciinema.org/connect/c4f303d3-deba-4121-b0ba-2b68307e70ba\n\nBrain-calc demonstration:\nhttps://asciinema.org/a/aCTPiRAfVmojJJTbHnDOZlGvs\n\nBrain-gcd demonstration:\nhttps://asciinema.org/a/jKSlQtW7c7VeHfmGbwE4yHk5H\n\nBrain-progression demonstration:\nhttps://asciinema.org/a/w9BwKbPpbd863xGMjPS5xzrtE\n\nBrain-prime demonstration:\nhttps://asciinema.org/a/t9Zl1ouyMnSmHkegKKDCwWlNo\n\n',
    'author': 'Roman Tatarenkov',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
}


setup(**setup_kwargs)
