### Hexlet tests and linter status:
[![Actions Status](https://github.com/tatarenkov-r-v/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/tatarenkov-r-v/python-project-49/actions)

<a href="https://codeclimate.com/github/tatarenkov-r-v/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/6dc7d84679b910c8758b/maintainability" /></a>

Brain-even demonstration:
https://asciinema.org/connect/c4f303d3-deba-4121-b0ba-2b68307e70ba

Brain-calc demonstration:
https://asciinema.org/a/aCTPiRAfVmojJJTbHnDOZlGvs

Brain-gcd demonstration:
https://asciinema.org/a/jKSlQtW7c7VeHfmGbwE4yHk5H

Brain-progression demonstration:
https://asciinema.org/a/w9BwKbPpbd863xGMjPS5xzrtE
